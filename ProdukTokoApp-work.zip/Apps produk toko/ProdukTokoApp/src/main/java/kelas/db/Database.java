package kelas.db;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.scene.image.Image;

public class Database {

    private static final Path FOLDER_DATA = Path.of(
            System.getProperty("user.dir"), "data"
    ).toAbsolutePath().normalize();

    private static final Path FILE_DATABASE = FOLDER_DATA.resolve("produk_toko.db");
    private static final Path FOLDER_GAMBAR = FOLDER_DATA.resolve("gambar");

    public static Connection bukaKoneksi() throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + FILE_DATABASE);
    }

    public static void prepareDatabase() throws IOException, SQLException {
        Files.createDirectories(FOLDER_DATA);
        Files.createDirectories(FOLDER_GAMBAR);
        System.out.println("DATABASE AKTIF: " + FILE_DATABASE);

        String sql = "CREATE TABLE IF NOT EXISTS produk ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "kode TEXT NOT NULL UNIQUE CHECK (length(trim(kode)) > 0), "
                + "nama TEXT NOT NULL CHECK (length(trim(nama)) > 0), "
                + "kategori TEXT NOT NULL CHECK (kategori IN ('Makanan', 'Minuman')), "
                + "harga INTEGER NOT NULL CHECK (harga > 0), "
                + "foto TEXT NOT NULL CHECK (length(trim(foto)) > 0)"
                + ")";

        try (Connection koneksi = bukaKoneksi();
             Statement perintah = koneksi.createStatement()) {
            perintah.executeUpdate(sql);

            // Migrasi otomatis jika file produk_toko.db lama belum memiliki kolom foto
            boolean punyaKolomFoto = false;
            try (ResultSet rs = perintah.executeQuery("PRAGMA table_info(produk)")) {
                while (rs.next()) {
                    if ("foto".equalsIgnoreCase(rs.getString("name"))) {
                        punyaKolomFoto = true;
                        break;
                    }
                }
            }
            if (!punyaKolomFoto) {
                perintah.executeUpdate(
                        "ALTER TABLE produk ADD COLUMN foto TEXT NOT NULL DEFAULT ''"
                );
            }
        }
    }

    public static String simpanFilePng(Path sumberPng) throws IOException {
        Files.createDirectories(FOLDER_GAMBAR);
        String namaAsli = sumberPng.getFileName().toString().replaceAll("[^a-zA-Z0-9._-]", "_");
        if (!namaAsli.toLowerCase().endsWith(".png")) {
            namaAsli = namaAsli + ".png";
        }
        String namaTujuan = System.currentTimeMillis() + "_" + namaAsli;
        Path tujuan = FOLDER_GAMBAR.resolve(namaTujuan);
        Files.copy(sumberPng, tujuan, StandardCopyOption.REPLACE_EXISTING);
        return namaTujuan;
    }

    public static Image muatGambarProduk(String namaFoto, double lebar, double tinggi) {
        if (namaFoto == null || namaFoto.isBlank()) {
            return null;
        }
        Path fileLokal = FOLDER_GAMBAR.resolve(namaFoto.trim());
        if (Files.exists(fileLokal)) {
            Image img = new Image(fileLokal.toUri().toString(), lebar, tinggi, true, true);
            if (!img.isError()) {
                return img;
            }
        }
        return null;
    }
}
