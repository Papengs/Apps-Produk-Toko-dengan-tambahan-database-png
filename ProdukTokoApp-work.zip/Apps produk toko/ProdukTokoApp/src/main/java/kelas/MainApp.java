package kelas;

import javafx.application.Application;
import javafx.stage.Stage;
import kelas.data.DataProduk;
import kelas.db.Database;

public class MainApp extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        Database.prepareDatabase();
        new Navigator(stage, new DataProduk()).bukaForm();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
