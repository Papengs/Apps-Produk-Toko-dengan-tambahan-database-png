package kelas.controller;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import kelas.Navigator;
import kelas.data.DataProduk;
import kelas.db.Database;
import kelas.model.Produk;

public class FormController {

    private static final int MAKS_PREVIEW = 4;

    @FXML
    private TextField namaField, hargaField;
    @FXML
    private ComboBox<String> kategoriBox;
    @FXML
    private Label namaFileFotoLabel, pesanLabel, infoPreviewLabel;
    @FXML
    private TilePane previewProdukPane;

    private Navigator navigator;
    private DataProduk data;
    private File filePngDipilih;

    @FXML
    private void initialize() {
        kategoriBox.getItems().addAll("Makanan", "Minuman");
        kategoriBox.setValue("Makanan");
    }

    public void setKonteks(Navigator navigator, DataProduk data) {
        this.navigator = navigator;
        this.data = data;
        muatPreviewTerakhir();
    }

    @FXML
    private void pilihPng() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Pilih Foto Produk (.png)");
        chooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("File Gambar PNG (*.png)", "*.png")
        );

        File dipilih = chooser.showOpenDialog(namaField.getScene().getWindow());
        if (dipilih != null) {
            filePngDipilih = dipilih;
            namaFileFotoLabel.setText(dipilih.getName());
            setPesan("", false);
        }
    }

    @FXML
    private void simpan() {
        if (filePngDipilih == null) {
            setPesan("Ambil foto produk (.png) terlebih dahulu sebelum menyimpan.", true);
            return;
        }

        try {
            long harga = Long.parseLong(hargaField.getText().trim());
            String nama = namaField.getText();
            String kategori = kategoriBox.getValue();

            // Validasi input sebelum menyalin file PNG
            new Produk("PR000", nama, kategori, harga, filePngDipilih.getName());

            String namaFotoTersimpan = Database.simpanFilePng(filePngDipilih.toPath());
            Produk tersimpan = data.tambah(nama, kategori, harga, namaFotoTersimpan);

            // Reset form agar siap untuk input produk berikutnya
            namaField.clear();
            hargaField.clear();
            filePngDipilih = null;
            namaFileFotoLabel.setText("Belum ada file .png dipilih");

            setPesan("Produk " + tersimpan.getKode() + " (" + tersimpan.getNama() + ") berhasil ditambahkan!", false);
            muatPreviewTerakhir();
        } catch (NumberFormatException e) {
            setPesan("Harga harus berupa bilangan bulat, contoh: 15000.", true);
        } catch (IllegalArgumentException e) {
            setPesan(e.getMessage(), true);
        } catch (IOException e) {
            setPesan("Gagal menyalin file foto PNG.", true);
            e.printStackTrace();
        } catch (SQLException e) {
            setPesan("Gagal menyimpan produk ke database.", true);
            e.printStackTrace();
        }
    }

    private void muatPreviewTerakhir() {
        if (data == null) {
            return;
        }
        previewProdukPane.getChildren().clear();
        try {
            ArrayList<Produk> terbaru = data.getTerbaru(MAKS_PREVIEW);
            infoPreviewLabel.setText("(" + terbaru.size() + " dari maksimal " + MAKS_PREVIEW + " penambahan terakhir)");

            if (terbaru.isEmpty()) {
                Label kosong = new Label("Belum ada produk yang ditambahkan. Produk yang disimpan akan muncul di sini (maksimal 4 terakhir).");
                kosong.getStyleClass().add("muted");
                kosong.setWrapText(true);
                previewProdukPane.getChildren().add(kosong);
                return;
            }

            for (Produk produk : terbaru) {
                previewProdukPane.getChildren().add(buatKartuProduk(produk));
            }
        } catch (SQLException e) {
            setPesan("Gagal memuat preview produk dari database.", true);
            e.printStackTrace();
        }
    }

    private VBox buatKartuProduk(Produk produk) {
        StackPane bingkai = new StackPane();
        bingkai.setPrefSize(185, 115);
        bingkai.setMinSize(185, 115);
        bingkai.setMaxSize(185, 115);
        bingkai.getStyleClass().add("preview-box");

        Image gambar = Database.muatGambarProduk(produk.getFoto(), 175, 105);
        if (gambar != null) {
            ImageView iv = new ImageView(gambar);
            iv.setFitWidth(175);
            iv.setFitHeight(105);
            iv.setPreserveRatio(true);
            bingkai.getChildren().add(iv);
        } else {
            Label tanpaFoto = new Label("Tidak ada foto");
            tanpaFoto.getStyleClass().add("muted");
            bingkai.getChildren().add(tanpaFoto);
        }

        Label kodeLabel = new Label(produk.getKode());
        kodeLabel.getStyleClass().add("kode-badge");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label kategoriLabel = new Label(produk.getKategori());
        kategoriLabel.getStyleClass().add("kategori-badge");

        HBox barisAtas = new HBox(6, kodeLabel, spacer, kategoriLabel);
        barisAtas.setAlignment(Pos.CENTER_LEFT);

        Label namaLabel = new Label(produk.getNama());
        namaLabel.setWrapText(true);
        namaLabel.getStyleClass().add("nama-produk");

        String hargaFormatted = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("id-ID")).format(produk.getHarga());
        Label hargaLabel = new Label(hargaFormatted);
        hargaLabel.getStyleClass().add("harga-produk");

        VBox kartu = new VBox(8, bingkai, barisAtas, namaLabel, hargaLabel);
        kartu.setPrefWidth(212);
        kartu.setMinWidth(212);
        kartu.setMaxWidth(212);
        kartu.getStyleClass().add("kartu-produk");
        kartu.setCursor(Cursor.HAND);
        kartu.setOnMouseClicked(event -> {
            try {
                navigator.bukaDetail(produk);
            } catch (IOException e) {
                setPesan("Detail produk gagal dibuka.", true);
                e.printStackTrace();
            }
        });

        return kartu;
    }

    private void setPesan(String teks, boolean error) {
        pesanLabel.getStyleClass().removeAll("error", "success");
        pesanLabel.getStyleClass().add(error ? "error" : "success");
        pesanLabel.setText(teks);
    }

    @FXML
    private void bukaDaftar() {
        try {
            navigator.bukaDaftar();
        } catch (IOException e) {
            setPesan("Gagal membuka daftar.", true);
            e.printStackTrace();
        }
    }
}
