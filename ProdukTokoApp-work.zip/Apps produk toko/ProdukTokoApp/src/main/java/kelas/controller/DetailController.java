package kelas.controller;

import java.io.IOException;
import java.text.NumberFormat;
import java.util.Locale;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import kelas.Navigator;
import kelas.db.Database;
import kelas.model.Produk;

public class DetailController {

    @FXML
    private Label kodeLabel, namaLabel, kategoriLabel, hargaLabel, fotoLabel, pesanLabel, tanpaFotoLabel;
    @FXML
    private ImageView fotoPreview;
    private Navigator navigator;

    public void setData(Navigator navigator, Produk p) {
        this.navigator = navigator;
        kodeLabel.setText(p.getKode());
        namaLabel.setText(p.getNama());
        kategoriLabel.setText(p.getKategori());
        hargaLabel.setText(NumberFormat.getCurrencyInstance(Locale.forLanguageTag("id-ID")).format(p.getHarga()));
        fotoLabel.setText("File gambar: " + p.getFoto());

        Image gambar = Database.muatGambarProduk(p.getFoto(), 180, 150);
        if (gambar != null) {
            fotoPreview.setImage(gambar);
            fotoPreview.setVisible(true);
            tanpaFotoLabel.setVisible(false);
        } else {
            fotoPreview.setImage(null);
            fotoPreview.setVisible(false);
            tanpaFotoLabel.setVisible(true);
        }
    }

    @FXML
    private void tambahLagi() {
        try {
            navigator.bukaForm();
        } catch (IOException e) {
            pesanLabel.setText("Gagal membuka form.");
            e.printStackTrace();
        }
    }

    @FXML
    private void bukaDaftar() {
        try {
            navigator.bukaDaftar();
        } catch (IOException e) {
            pesanLabel.setText("Gagal membuka daftar.");
            e.printStackTrace();
        }
    }
}
