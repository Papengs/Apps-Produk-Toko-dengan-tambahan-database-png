package kelas.data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import kelas.db.Database;
import kelas.model.Produk;

public class ProdukRepository {

    public void add(Produk produk) throws SQLException {
        String sql = "INSERT INTO produk (kode, nama, kategori, harga, foto) VALUES (?, ?, ?, ?, ?)";
        try (Connection koneksi = Database.bukaKoneksi();
             PreparedStatement perintah = koneksi.prepareStatement(sql)) {
            perintah.setString(1, produk.getKode());
            perintah.setString(2, produk.getNama());
            perintah.setString(3, produk.getKategori());
            perintah.setLong(4, produk.getHarga());
            perintah.setString(5, produk.getFoto());
            perintah.executeUpdate();
        }
    }

    public ArrayList<Produk> getAll() throws SQLException {
        ArrayList<Produk> daftar = new ArrayList<>();
        String sql = "SELECT id, kode, nama, kategori, harga, foto FROM produk ORDER BY id";
        try (Connection koneksi = Database.bukaKoneksi();
             PreparedStatement perintah = koneksi.prepareStatement(sql);
             ResultSet hasil = perintah.executeQuery()) {
            while (hasil.next()) {
                daftar.add(bacaBaris(hasil));
            }
        }
        return daftar;
    }

    public ArrayList<Produk> getTerbaru(int batas) throws SQLException {
        ArrayList<Produk> daftar = new ArrayList<>();
        String sql = "SELECT id, kode, nama, kategori, harga, foto FROM produk ORDER BY id DESC LIMIT ?";
        try (Connection koneksi = Database.bukaKoneksi();
             PreparedStatement perintah = koneksi.prepareStatement(sql)) {
            perintah.setInt(1, batas);
            try (ResultSet hasil = perintah.executeQuery()) {
                while (hasil.next()) {
                    daftar.add(bacaBaris(hasil));
                }
            }
        }
        return daftar;
    }

    public void delete(long id) throws SQLException {
        String sql = "DELETE FROM produk WHERE id = ?";
        try (Connection koneksi = Database.bukaKoneksi();
             PreparedStatement perintah = koneksi.prepareStatement(sql)) {
            perintah.setLong(1, id);
            perintah.executeUpdate();
        }
    }

    public String generateKodeBerikutnya() throws SQLException {
        int maxUrutan = 0;
        String sql = "SELECT kode FROM produk";
        try (Connection koneksi = Database.bukaKoneksi();
             PreparedStatement perintah = koneksi.prepareStatement(sql);
             ResultSet hasil = perintah.executeQuery()) {
            while (hasil.next()) {
                String kode = hasil.getString("kode");
                if (kode != null && kode.startsWith("PR")) {
                    try {
                        int nomor = Integer.parseInt(kode.substring(2));
                        if (nomor > maxUrutan) {
                            maxUrutan = nomor;
                        }
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
        }
        return String.format("PR%03d", maxUrutan + 1);
    }

    private Produk bacaBaris(ResultSet hasil) throws SQLException {
        long id = hasil.getLong("id");
        String kode = hasil.getString("kode");
        String nama = hasil.getString("nama");
        String kategori = hasil.getString("kategori");
        long harga = hasil.getLong("harga");
        String foto = hasil.getString("foto");
        if (foto == null || foto.isBlank()) {
            foto = "tanpa_foto.png";
        }
        return new Produk(id, kode, nama, kategori, harga, foto);
    }
}
