package kelas.data;

import java.sql.SQLException;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import kelas.model.Produk;

public class DataProduk {

    private final ProdukRepository repository = new ProdukRepository();

    public ObservableList<Produk> getDaftar() throws SQLException {
        return FXCollections.unmodifiableObservableList(
                FXCollections.observableArrayList(repository.getAll())
        );
    }

    public ArrayList<Produk> getTerbaru(int batas) throws SQLException {
        return repository.getTerbaru(batas);
    }

    public Produk tambah(String nama, String kategori, long harga, String foto) throws SQLException {
        String kode = repository.generateKodeBerikutnya();
        Produk p = new Produk(kode, nama, kategori, harga, foto);
        repository.add(p);
        return p;
    }

    public void hapus(Produk produk) throws SQLException {
        if (produk != null) {
            repository.delete(produk.getId());
        }
    }
}
